-- --------------------------------------------------------
-- --------------------------------------------------------
-- vietr933, duyph635 2025-05-15
-- Create a view for regression analyst (Project delC)
-- --------------------------------------------------------
-- --------------------------------------------------------

-- --------------------------------------------------------
-- Create a view that required from the project.


DROP VIEW IF EXISTS View_delC CASCADE;
DROP VIEW IF EXISTS View_delC_Obligatorisk CASCADE;
DROP VIEW IF EXISTS View_delC_Valbara CASCADE;



CREATE VIEW View_delC AS SELECT studera.personnummer,student.average_score, student.programkod, SUM(CASE 
    WHEN studera.rate in ('G','VG') THEN kurs.college_credits
    ELSE 0 END) AS totalt_point 
	FROM studera 
	LEFT JOIN kurs ON studera.kurskod = kurs.pk_kurskod 
	LEFT JOIN student ON studera.personnummer = student.pk_personnummer 
	LEFT JOIN kurs_programmet ON studera.kurskod = kurs_programmet.kurskod
    GROUP BY personnummer;


CREATE VIEW View_delC_Obligatorisk AS SELECT studera.personnummer,student.average_score, student.programkod, SUM(CASE 
    WHEN studera.rate in ('G','VG') THEN kurs.college_credits
    ELSE 0 END) AS totalt_point 
	FROM studera 
	LEFT JOIN kurs ON studera.kurskod = kurs.pk_kurskod 
	LEFT JOIN student ON studera.personnummer = student.pk_personnummer 
	LEFT JOIN kurs_programmet ON studera.kurskod = kurs_programmet.kurskod
    WHERE kurs_programmet.Obligatorisk = 1
    GROUP BY personnummer;


CREATE VIEW View_delC_Valbara AS SELECT studera.personnummer,student.average_score, student.programkod, SUM(CASE 
    WHEN studera.rate in ('G','VG') THEN kurs.college_credits
    ELSE 0 END) AS totalt_point 
	FROM studera 
	LEFT JOIN kurs ON studera.kurskod = kurs.pk_kurskod 
	LEFT JOIN student ON studera.personnummer = student.pk_personnummer 
	LEFT JOIN kurs_programmet ON studera.kurskod = kurs_programmet.kurskod
    WHERE kurs_programmet.Obligatorisk = 0
    GROUP BY personnummer;



-- --------------------------------------------------------
-- --------------------------------------------------------

-- ------------------------------------------------------------
-- Create new tables which do not have any key in it, based on existed tables.

DROP TABLE IF EXISTS kurs_noindex CASCADE;
DROP TABLE IF EXISTS studera_noindex CASCADE;
DROP TABLE IF EXISTS student_noindex CASCADE;
DROP TABLE IF EXISTS kurs_programmet_noindex CASCADE;


CREATE TABLE kurs_noindex as select * from kurs;
CREATE TABLE studera_noindex as select * from studera;
CREATE TABLE student_noindex as select * from student;
CREATE TABLE kurs_programmet_noindex as select * from kurs_programmet;


DROP VIEW IF EXISTS View_delC_noindex CASCADE;
DROP VIEW IF EXISTS View_delC_Obligatorisk_noindex CASCADE;

CREATE VIEW View_delC_noindex AS SELECT studera_noindex.personnummer,student_noindex.average_score, student_noindex.programkod,studera_noindex.kurskod,kurs_programmet_noindex.Obligatorisk, SUM(CASE 
    WHEN studera_noindex.rate in ('G','VG') THEN kurs_noindex.college_credits
    ELSE 0 END) AS totalt_point
	FROM studera_noindex 
	LEFT JOIN kurs_noindex ON studera_noindex.kurskod = kurs_noindex.pk_kurskod 
	LEFT JOIN student_noindex ON studera_noindex.personnummer = student_noindex.pk_personnummer 
	LEFT JOIN kurs_programmet_noindex ON studera_noindex.kurskod = kurs_programmet_noindex.kurskod
    GROUP BY personnummer;


CREATE VIEW View_delC_Obligatorisk_noindex AS SELECT studera_noindex.personnummer,student_noindex.average_score, student_noindex.programkod, SUM(CASE 
    WHEN studera_noindex.rate in ('G','VG') THEN kurs_noindex.college_credits
    ELSE 0 END) AS totalt_point 
	FROM studera_noindex 
	LEFT JOIN kurs_noindex ON studera_noindex.kurskod = kurs_noindex.pk_kurskod 
	LEFT JOIN student_noindex ON studera_noindex.personnummer = student_noindex.pk_personnummer 
	LEFT JOIN kurs_programmet_noindex ON studera_noindex.kurskod = kurs_programmet_noindex.kurskod
    WHERE kurs_programmet_noindex.Obligatorisk = 1
    GROUP BY personnummer;


-- ---------------------------------------------------------
-- Create a view that based on the tables without indexes.



