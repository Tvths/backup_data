-- --------------------------------------------------------
-- Continuing with the project we describe the steps to find the difference
-- between the tables with indexes and without indexes.

-- --------------------------------------------------------
-- Execute query code to check out the time it takes to find the output.


mysql> select AVG(totalt_point) as avg_point from (select sum(totalt_point) as totalt_point from View_delC_Obligatorisk  group by personnummer) as per_student;
+-----------+
| avg_point |
+-----------+
|   36.6515 |
+-----------+
1 row in set (0,04 sec)




-- ------------------------------------------------------------
-- Execute query code with same purpose but use the tables with no any keys we created and check out the
-- difference of time it takes to find out the ouput.


mysql> select AVG(totalt_point) as avg_point from (select sum(totalt_point) as totalt_point from View_delC_Obligatorisk_noindex  group by personnummer) as per_student;
+-----------+
| avg_point |
+-----------+
|   36.6515 |
+-----------+
1 row in set (4,04 sec)




