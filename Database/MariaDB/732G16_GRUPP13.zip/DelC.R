install.packages(c("RMySQL","dplyr","DBI", "tidyverse","cowplot","kableExtra"))
library(DBI)
library(RMySQL)
library(dplyr)
library(ggplot2)
library(cowplot)
library(kableExtra)

con <- dbConnect(RMySQL::MySQL(),
                 user = "vietr933",
                 password = "vietr93377a5",
                 dbname = "vietr933",
                 host = "mariadb.edu.liu.se")


data <- dbGetQuery(con,"select * from View_delC;")
data_Obligatorisk <- dbGetQuery(con,"select * from View_delC_Obligatorisk")
data_Valbara <- dbGetQuery(con,"select * from View_delC_Valbara")



dbDisconnect(con)


### LIU50004 LIU50007 LIU50008 LIU50100 LIU50153
 

############################Spridningsdiagram (Alla program + Alla kurser)##########################
summary(data)
allaprogram_allakurser <- lm(totalt_point ~ average_score, data = data)
summary(allaprogram_allakurser)
p1 <- ggplot(data, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "Spridningsdiagram med regressionslinje av alla programmet och alla kurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")

Program_Liu50004_allakurser <- data[data$programkod == "LIU50004",]
Program_Liu50004_allakurser_lm <- lm(totalt_point ~ average_score, data = Program_Liu50004_allakurser)
summary(Program_Liu50004_allakurser_lm)
summary(Program_Liu50004_allakurser)
  anova(Program_Liu50004_allakurser_lm)
p1_1 <- ggplot(Program_Liu50004_allakurser, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50004 och alla kurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p1_1


Program_Liu50007_allakurser <- data[data$programkod == "LIU50007",]
Program_Liu50007_allakurser_lm <- lm(totalt_point ~ average_score, data = Program_Liu50007_allakurser)
summary(Program_Liu50007_allakurser_lm)
summary(Program_Liu50007_allakurser)
anova(Program_Liu50007_allakurser_lm)
p1_2 <- ggplot(Program_Liu50007_allakurser, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50007 och alla kurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p1_2


Program_Liu50008_allakurser <- data[data$programkod == "LIU50008",]
Program_Liu50008_allakurser_lm <- lm(totalt_point ~ average_score, data = Program_Liu50008_allakurser)
summary(Program_Liu50008_allakurser_lm)
summary(Program_Liu50008_allakurser)
anova(Program_Liu50008_allakurser_lm)
p1_3 <- ggplot(Program_Liu50008_allakurser, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50008 och alla kurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p1_3


Program_Liu50100_allakurser <- data[data$programkod == "LIU50100",]
Program_Liu50100_allakurser_lm <- lm(totalt_point ~ average_score, data = Program_Liu50100_allakurser)
summary(Program_Liu50100_allakurser_lm)
summary(Program_Liu50100_allakurser)
anova(Program_Liu50100_allakurser_lm)
p1_4 <- ggplot(Program_Liu50100_allakurser, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50100 och alla kurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p1_4


Program_Liu50153_allakurser <- data[data$programkod == "LIU50153",]
Program_Liu50153_allakurser_lm <- lm(totalt_point ~ average_score, data = Program_Liu50153_allakurser)
summary(Program_Liu50153_allakurser_lm)
summary(Program_Liu50153_allakurser)
anova(Program_Liu50153_allakurser_lm)
p1_5 <- ggplot(Program_Liu50153_allakurser, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50153 och alla kurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p1_5

plot_grid(p1_1,p1_2,p1_3,p1_4,p1_5,ncol = 2)





##############################Spridningsdiagram (Alla program + Obligatoriska kurser)######################
summary(data_Obligatorisk)
allaprogram_obligatoriskakurser<- lm(totalt_point ~ average_score, data = data_Obligatorisk)
summary(allaprogram_obligatoriskakurser)
p2 <- ggplot(data_Obligatorisk, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "alla Programmet och obligatotiskkurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")


LIU50004_obligatoriska <- data_Obligatorisk[data_Obligatorisk$programkod == "LIU50004",]
LIU50004_obligatoriska_lm <- lm(totalt_point ~ average_score, data = LIU50004_obligatoriska)
summary(LIU50004_obligatoriska_lm)
summary(LIU50004_obligatoriska)
p2_1 <- ggplot(LIU50004_obligatoriska, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50004 och obligatotiskkurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p2_1

LIU50007_obligatoriska <- data_Obligatorisk[data_Obligatorisk$programkod == "LIU50007",]
LIU50007_obligatoriska_lm <- lm(totalt_point ~ average_score, data = LIU50007_obligatoriska)
summary(LIU50007_obligatoriska_lm)
summary(LIU50007_obligatoriska)
p2_2 <- ggplot(LIU50007_obligatoriska, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50007 och obligatotiskkurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p2_2


LIU50008_obligatoriska <- data_Obligatorisk[data_Obligatorisk$programkod == "LIU50008",]
LIU50008_obligatoriska_lm <- lm(totalt_point ~ average_score, data = LIU50008_obligatoriska)
summary(LIU50008_obligatoriska_lm)
summary(LIU50008_obligatoriska)
p2_3 <- ggplot(LIU50008_obligatoriska, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50008 och obligatotiskkurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p2_3


LIU50100_obligatoriska <- data_Obligatorisk[data_Obligatorisk$programkod == "LIU50100",]
LIU50100_obligatoriska_lm <- lm(totalt_point ~ average_score, data = LIU50100_obligatoriska)
summary(LIU50100_obligatoriska_lm)
summary(LIU50100_obligatoriska)
p2_4 <- ggplot(LIU50100_obligatoriska, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50100 och obligatotiskkurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p2_4


LIU50153_obligatoriska <- data_Obligatorisk[data_Obligatorisk$programkod == "LIU50153",]
LIU50153_obligatoriska_lm <- lm(totalt_point ~ average_score, data = LIU50153_obligatoriska)
summary(LIU50153_obligatoriska_lm)
summary(LIU50153_obligatoriska)
p2_5 <- ggplot(LIU50153_obligatoriska, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50153 och obligatotiskkurser",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p2_5

plot_grid(p2_1,p2_2,p2_3,p2_4,p2_5,ncol = 2)





############################Spridningsdiagram (Alla program + Valbara kurser)################################
summary(data_Valbara)
allaprogram_valbarakurser<- lm(totalt_point ~ average_score, data = data_Valbara)
summary(allaprogram_valbarakurser)
summary(data_Valbara)
p3 <- ggplot(data_Valbara, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "Spridningsdiagram med regressionslinje",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")

LIU50004_valbara <- data_Valbara[data_Valbara$programkod == "LIU50004",]
LIU50004_valbara_lm <- lm(totalt_point ~ average_score, data = LIU50004_valbara)
summary(LIU50004_valbara_lm)
summary(LIU50004_valbara)
p3_1 <- ggplot(LIU50004_valbara, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50004 och valbara",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p3_1


LIU50007_valbara <- data_Valbara[data_Valbara$programkod == "LIU50007",]
LIU50007_valbara_lm <- lm(totalt_point ~ average_score, data = LIU50007_valbara)
summary(LIU50007_valbara_lm)
summary(LIU50007_valbara)
p3_2 <- ggplot(LIU50007_valbara, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50007 och valbara",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p3_2


LIU50008_valbara <- data_Valbara[data_Valbara$programkod == "LIU50008",]
LIU50008_valbara_lm <- lm(totalt_point ~ average_score, data = LIU50008_valbara)
summary(LIU50008_valbara_lm)
summary(LIU50008_valbara)
p3_3 <- ggplot(LIU50008_valbara, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50008 och valbara",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p3_3


LIU50100_valbara <- data_Valbara[data_Valbara$programkod == "LIU50100",]
LIU50100_valbara_lm <- lm(totalt_point ~ average_score, data = LIU50100_valbara)
summary(LIU50100_valbara_lm)
summary(LIU50100_valbara)
p3_4 <- ggplot(LIU50100_valbara, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50100 och valbara",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p3_4


LIU50153_valbara <- data_Valbara[data_Valbara$programkod == "LIU50153",]
LIU50153_valbara_lm <- lm(totalt_point ~ average_score, data = LIU50153_valbara)
summary(LIU50153_valbara_lm)
summary(LIU50153_valbara)
p3_5 <- ggplot(LIU50153_valbara, aes(x = average_score, y = totalt_point)) +
  geom_point() +                           # spridningsdiagram
  geom_smooth(method = "lm", se = TRUE,formula = 'y ~ x') +  # regressionslinje med konfidensintervall
  labs(title = "LIU50153 och valbara",
       x = "Genomsnittligt betyg",
       y = "Totala poäng")
p3_5

plot_grid(p3_1,p3_2,p3_3,p3_4,p3_5,ncol = 2)

### kombinera plot av alla programmet
plot_grid(p1,p2,p3)


###################################################################################


### Eftersom alla modeller har som samma beroende och oberoende variabler, så vi använda
### dessa förklarings förmåga för att kolla om förmåga av förklaras av data för varje modellen.
### Därefter kan vi hitta den bäst modellen.

# Lägg modellerna i en lista
modellista <- list(
  Program_Liu50004_allakurser_lm,
  Program_Liu50007_allakurser_lm,
  Program_Liu50008_allakurser_lm,
  Program_Liu50100_allakurser_lm,
  Program_Liu50153_allakurser_lm,
  LIU50004_obligatoriska_lm,
  LIU50007_obligatoriska_lm,
  LIU50008_obligatoriska_lm,
  LIU50100_obligatoriska_lm,
  LIU50153_obligatoriska_lm,
  LIU50004_valbara_lm,
  LIU50007_valbara_lm,
  LIU50008_valbara_lm,
  LIU50100_valbara_lm,
  LIU50153_valbara_lm
)

# Namn (valfritt om du vill använda dem i tabellen)
modellnamn <- c(
  "Liu50004_allakurser", "Liu50007_allakurser", "Liu50008_allakurser", "Liu50100_allakurser", "Liu50153_allakurser",
  "LIU50004_obligatoriska", "LIU50007_obligatoriska", "LIU50008_obligatoriska", "LIU50100_obligatoriska", "LIU50153_obligatoriska",
  "LIU50004_valbara", "LIU50007_valbara", "LIU50008_valbara", "LIU50100_valbara", "LIU50153_valbara"
)

# Skapa tabell med R²
r2_resultat <- sapply(modellista, function(mod) summary(mod)$r.squared)

# Lägg i en data.frame
r2_tabell <- data.frame(
  Modell = modellnamn,
  R2 = round(r2_resultat, 3)
)
### skapa R2 tabell
r2_tabell %>%
  kable(format = "html", digits = 3, caption = "Förklaringsgrad per modell") %>%
  kable_styling("striped", full_width = F)
