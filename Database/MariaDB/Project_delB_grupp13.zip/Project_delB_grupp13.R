### Installera alla paket som behöver i denna projekt.
install.packages(c("RMySQL","dplyr","DBI"))
library(DBI)
library(RMySQL)
library(dplyr)



# Funktion för att läsa CSV fil rad för rad och organisera datan
funktion <- function(file_path) {
  # Skapa databasanslutning
  con <- dbConnect(RMySQL::MySQL(),
                   user = "vietr933",
                   password = "vietr93377a5",
                   dbname = "vietr933",
                   host = "mariadb.edu.liu.se")
  ### Läsa in 10000 rader från data fil innan dela upp till olika tabeller för att skriver till databas.
  size <- 10000
  colnames <- names(read.csv(file_path, sep = ";", nrows = 0))
  skip_lines <- 1
  
  
  while(nrow(data) < size){
    data <- read.csv(file_path,sep=";",skip=skip_lines,nrow=size,header=FALSE,stringsAsFactors = FALSE)
    colnames(data) <- colnames
    
    ### Organisera data till tabeller.
    student <- data %>%
      ### väljer vilken kolumner som borde innehålls i databas.
      select(Personnummer, Namn, Medelbetyg, Programkod) %>%
      ### returnera unika värderna basera på personnummer.
      distinct(Personnummer, .keep_all = TRUE) %>%
      ### Nämne av kolumner måste lika med nämne som vi skapade i databas.
      rename(pk_personnummer = Personnummer,
             name = Namn,
             average_score = Medelbetyg,
             programkod = Programkod)
    ### På samma sätt med alla tabler nedan.
    programmet <- data %>%
      select(Programkod, Programnamn) %>%
      distinct(Programkod, .keep_all = TRUE) %>%
      rename(pk_programkod = Programkod,
             programname = Programnamn)
    
    kurs <- data %>%
      select(Kurskod, Kurs, Poang) %>%
      distinct(Kurskod, .keep_all = TRUE) %>%
      rename(pk_kurskod = Kurskod,
             kursname = Kurs,
             college_credits = Poang)
    
    studera <- data %>%
      select(Personnummer, Kurskod, Betyg) %>%
      distinct(Personnummer, Kurskod, .keep_all = TRUE) %>%
      rename(personnummer = Personnummer,
             kurskod = Kurskod,
             rate = Betyg)
    
    kurs_programmet <- data %>%
      select(Kurskod, Programkod, Obligatorisk) %>%
      distinct(Kurskod, Programkod, .keep_all = TRUE) %>%
      rename(kurskod = Kurskod,
             programkod = Programkod,
             obligatorisk = Obligatorisk)
    
    # Skriv blocket till databasen
    dbWriteTable(con, "programmet", programmet, row.names = FALSE, append = TRUE)
    dbWriteTable(con, "kurs", kurs, row.names = FALSE, append = TRUE)
    dbWriteTable(con, "student", student, row.names = FALSE, append = TRUE)
    dbWriteTable(con, "kurs_programmet", kurs_programmet, row.names = FALSE, append = TRUE)
    dbWriteTable(con, "studera", studera, row.names = FALSE, append = TRUE)
    
    
    skip_lines <- skip_lines + size
    
  }
  
  dbDisconnect(con)
}

### filväg som pekar till stället där datafil finns. 
file_path <- "X:/732G16_database/732G16_Project_delB/group-13-data.csv"
### anropa funktion.
funktion(file_path)






